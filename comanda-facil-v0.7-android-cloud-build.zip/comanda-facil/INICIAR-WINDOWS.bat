@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale a versao LTS em https://nodejs.org/ e execute este arquivo novamente.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Instalando dependencias do Comanda Facil...
  call npm install
  if errorlevel 1 pause & exit /b 1
)
echo.
echo Iniciando Comanda Facil...
echo No computador: http://localhost:3000
echo No celular: use o endereco IP exibido abaixo, conectado ao mesmo Wi-Fi.
echo Para encerrar, pressione Ctrl+C.
echo.
call npm start
pause
