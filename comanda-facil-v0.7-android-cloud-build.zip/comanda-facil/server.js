const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const Database = require('better-sqlite3');
const os = require('os');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new Database(path.join(__dirname, 'comanda-facil.db'));
const PORT = Number(process.env.PORT || 3000);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const backupDir = path.join(__dirname, 'backups');
fs.mkdirSync(backupDir, { recursive: true });

db.exec(`
CREATE TABLE IF NOT EXISTS tables_room (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'Geral', price REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, table_id INTEGER, customer TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, notes TEXT DEFAULT '', FOREIGN KEY(table_id) REFERENCES tables_room(id));
CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER, name TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 1, unit_price REAL NOT NULL DEFAULT 0, notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'new', FOREIGN KEY(order_id) REFERENCES orders(id));
`);

db.exec(`
CREATE TABLE IF NOT EXISTS cash_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, opened_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, closed_at TEXT, opening_amount REAL NOT NULL DEFAULT 0, closing_amount REAL, status TEXT NOT NULL DEFAULT 'open');
CREATE TABLE IF NOT EXISTS cash_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, type TEXT NOT NULL, amount REAL NOT NULL, method TEXT NOT NULL DEFAULT 'cash', description TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(session_id) REFERENCES cash_sessions(id));
CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, session_id INTEGER NOT NULL, method TEXT NOT NULL, amount REAL NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(session_id) REFERENCES cash_sessions(id));
CREATE TABLE IF NOT EXISTS ingredients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT 'un', stock REAL NOT NULL DEFAULT 0, min_stock REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS recipes (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, ingredient_id INTEGER NOT NULL, quantity REAL NOT NULL, UNIQUE(product_id,ingredient_id), FOREIGN KEY(product_id) REFERENCES products(id), FOREIGN KEY(ingredient_id) REFERENCES ingredients(id));
CREATE TABLE IF NOT EXISTS stock_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, ingredient_id INTEGER NOT NULL, type TEXT NOT NULL, quantity REAL NOT NULL, description TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(ingredient_id) REFERENCES ingredients(id));
CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'Geral', amount REAL NOT NULL, payment_method TEXT NOT NULL DEFAULT 'cash', expense_date TEXT NOT NULL DEFAULT (date('now','localtime')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'Garçom', active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS app_users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS auth_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES app_users(id));
`);

try { db.exec('ALTER TABLE orders ADD COLUMN employee_id INTEGER'); } catch (_e) { /* coluna já existe em bancos atualizados */ }

const count = db.prepare('SELECT COUNT(*) n FROM products').get().n;
if (!count) db.prepare('INSERT INTO products (name,category,price) VALUES (?,?,?), (?,?,?), (?,?,?), (?,?,?)').run('Refrigerante','Bebidas',6,'Água mineral','Bebidas',3,'Hambúrguer','Lanches',22,'Pizza mussarela','Pizzas',38);

function broadcast() { io.emit('data:changed'); }
const hashPassword = (password, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, hash: crypto.scryptSync(password, salt, 64).toString('hex') });
const tokenDigest = token => crypto.createHash('sha256').update(token).digest('hex');
const publicUser = u => ({ id:u.id, name:u.name, username:u.username, role:u.role });
app.get('/api/auth/status', (_req,res) => res.json({ setupRequired: db.prepare('SELECT COUNT(*) n FROM app_users').get().n === 0 }));
app.post('/api/auth/setup', (req,res) => {
  if (db.prepare('SELECT COUNT(*) n FROM app_users').get().n) return res.status(403).json({error:'A configuração inicial já foi concluída.'});
  const name=String(req.body.name||'').trim(), username=String(req.body.username||'').trim().toLowerCase(), password=String(req.body.password||'');
  if(!name || !/^[a-z0-9._-]{3,30}$/.test(username) || password.length<10) return res.status(400).json({error:'Informe nome, usuário (3 a 30 caracteres) e senha com pelo menos 10 caracteres.'});
  const pw=hashPassword(password); const info=db.prepare('INSERT INTO app_users(name,username,password_hash,role) VALUES(?,?,?,?)').run(name,username,`${pw.salt}:${pw.hash}`,'admin');
  const token=crypto.randomBytes(32).toString('hex'); db.prepare("INSERT INTO auth_sessions(user_id,token_hash,expires_at) VALUES(?,?,datetime('now','+7 days'))").run(info.lastInsertRowid,tokenDigest(token));
  res.status(201).json({token,user:publicUser(db.prepare('SELECT * FROM app_users WHERE id=?').get(info.lastInsertRowid))});
});
app.post('/api/auth/login', (req,res) => {
  const username=String(req.body.username||'').trim().toLowerCase(), password=String(req.body.password||'');
  const user=db.prepare('SELECT * FROM app_users WHERE username=? AND active=1').get(username);
  if(!user) return res.status(401).json({error:'Usuário ou senha inválidos.'});
  const [salt,expected]=user.password_hash.split(':'); const actual=crypto.scryptSync(password,salt,64).toString('hex');
  if(!crypto.timingSafeEqual(Buffer.from(actual,'hex'),Buffer.from(expected,'hex'))) return res.status(401).json({error:'Usuário ou senha inválidos.'});
  const token=crypto.randomBytes(32).toString('hex'); db.prepare("INSERT INTO auth_sessions(user_id,token_hash,expires_at) VALUES(?,?,datetime('now','+7 days'))").run(user.id,tokenDigest(token));
  res.json({token,user:publicUser(user)});
});
app.use('/api', (req,res,next) => {
  if (['/health','/auth/status','/auth/setup','/auth/login','/auth/logout'].includes(req.path)) return next();
  const header=String(req.headers.authorization||''); const token=header.startsWith('Bearer ')?header.slice(7):'';
  if(!token) return res.status(401).json({error:'Faça login para continuar.'});
  const user=db.prepare("SELECT u.* FROM auth_sessions s JOIN app_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>datetime('now') AND u.active=1").get(tokenDigest(token));
  if(!user) return res.status(401).json({error:'Sessão expirada. Entre novamente.'});
  req.user=user;
  const p=req.path, m=req.method, role=user.role;
  if(role==='admin') return next();
  if(role==='manager' && !p.startsWith('/auth/users') && !p.startsWith('/backup')) return next();
  const allowed = role==='cashier' ? ((m==='GET' && ['/tables','/products','/orders','/summary','/cash','/orders/'].some(x=>p===x||p.startsWith(x))) || p.startsWith('/orders/') && ['POST','GET'].includes(m) || p.startsWith('/cash') && ['GET','POST'].includes(m))
    : role==='waiter' ? ((m==='GET' && ['/tables','/products','/orders','/employees','/summary'].includes(p)) || (m==='POST' && (p==='/orders' || /^\/orders\/\d+\/items$/.test(p))) || (m==='PATCH' && /^\/orders\/\d+$/.test(p)))
    : role==='kitchen' ? ((m==='GET' && ['/tables','/products','/orders','/summary'].includes(p)) || (m==='PATCH' && /^\/items\/\d+\/status$/.test(p))) : false;
  if(!allowed) return res.status(403).json({error:'Seu perfil não tem permissão para esta operação.'});
  next();
});
app.get('/api/auth/me',(req,res)=>res.json({user:publicUser(req.user)}));
app.post('/api/auth/logout',(req,res)=>{const h=String(req.headers.authorization||'');if(h.startsWith('Bearer '))db.prepare('DELETE FROM auth_sessions WHERE token_hash=?').run(tokenDigest(h.slice(7)));res.json({ok:true});});
app.get('/api/auth/users',(req,res)=>res.json(db.prepare('SELECT id,name,username,role,active,created_at FROM app_users ORDER BY id').all()));
app.post('/api/auth/users',(req,res)=>{const name=String(req.body.name||'').trim(),username=String(req.body.username||'').trim().toLowerCase(),password=String(req.body.password||''),role=String(req.body.role||'');if(!name||!/^[a-z0-9._-]{3,30}$/.test(username)||password.length<10||!['manager','cashier','waiter','kitchen'].includes(role))return res.status(400).json({error:'Confira nome, usuário, senha (mínimo 10 caracteres) e perfil.'});try{const pw=hashPassword(password);const info=db.prepare('INSERT INTO app_users(name,username,password_hash,role) VALUES(?,?,?,?)').run(name,username,`${pw.salt}:${pw.hash}`,role);res.status(201).json({id:info.lastInsertRowid});}catch(e){res.status(400).json({error:'Não foi possível cadastrar. O usuário pode já existir.'});}});
app.patch('/api/auth/users/:id/active',(req,res)=>{const active=req.body.active?1:0;if(Number(req.params.id)===req.user.id&&!active)return res.status(400).json({error:'Não é possível desativar o próprio usuário.'});db.prepare('UPDATE app_users SET active=? WHERE id=?').run(active,req.params.id);if(!active)db.prepare('DELETE FROM auth_sessions WHERE user_id=?').run(req.params.id);res.json({ok:true});});
async function createBackup(){const stamp=new Date().toISOString().replace(/[:.]/g,'-');const target=path.join(backupDir,`comanda-facil-${stamp}.db`);await db.backup(target);const files=fs.readdirSync(backupDir).filter(f=>f.endsWith('.db')).sort().reverse();for(const old of files.slice(30))fs.unlinkSync(path.join(backupDir,old));return target;}
app.post('/api/backup',(req,res)=>createBackup().then(file=>res.json({ok:true,file:path.basename(file)})).catch(e=>res.status(500).json({error:'Falha ao criar backup: '+e.message})));
app.get('/api/backup/latest',(req,res)=>{const files=fs.readdirSync(backupDir).filter(f=>f.endsWith('.db')).sort().reverse();if(!files.length)return res.status(404).json({error:'Ainda não há backup. Crie o primeiro backup.'});res.download(path.join(backupDir,files[0]));});
app.get('/api/health', (_req,res) => res.json({ok:true, name:'Comanda Fácil'}));
app.get('/api/tables', (_req,res) => res.json(db.prepare(`SELECT t.*, (SELECT o.id FROM orders o WHERE o.table_id=t.id AND o.status='open' ORDER BY o.id DESC LIMIT 1) order_id, (SELECT COUNT(*) FROM orders o WHERE o.table_id=t.id AND o.status='open') open_count FROM tables_room t WHERE active=1 ORDER BY id`).all()));
app.post('/api/tables', (req,res) => {
  const name = String(req.body.name || '').trim(); if (!name) return res.status(400).json({error:'Informe o nome da mesa.'});
  const info = db.prepare('INSERT INTO tables_room(name) VALUES(?)').run(name); broadcast(); res.status(201).json({id:info.lastInsertRowid,name});
});
app.delete('/api/tables/:id', (req,res) => { db.prepare('UPDATE tables_room SET active=0 WHERE id=?').run(req.params.id); broadcast(); res.json({ok:true}); });
app.get('/api/employees', (_req,res) => res.json(db.prepare('SELECT * FROM employees WHERE active=1 ORDER BY name').all()));
app.post('/api/employees', (req,res) => { const name=String(req.body.name||'').trim(),role=String(req.body.role||'Garçom').trim(); if(!name)return res.status(400).json({error:'Informe o nome do funcionário.'}); const info=db.prepare('INSERT INTO employees(name,role) VALUES(?,?)').run(name,role||'Garçom'); broadcast(); res.status(201).json({id:info.lastInsertRowid}); });
app.get('/api/products', (_req,res) => res.json(db.prepare('SELECT * FROM products WHERE active=1 ORDER BY category,name').all()));
app.post('/api/products', (req,res) => {
  const {name,category='Geral',price=0}=req.body; if (!String(name||'').trim() || !Number.isFinite(Number(price)) || Number(price)<0) return res.status(400).json({error:'Nome e preço válido são obrigatórios.'});
  const info=db.prepare('INSERT INTO products(name,category,price) VALUES(?,?,?)').run(String(name).trim(),String(category),Number(price)); broadcast(); res.status(201).json({id:info.lastInsertRowid});
});
app.get('/api/orders', (_req,res) => {
  const orders=db.prepare(`SELECT o.*, t.name table_name, e.name employee_name FROM orders o LEFT JOIN tables_room t ON t.id=o.table_id LEFT JOIN employees e ON e.id=o.employee_id WHERE o.status IN ('open','closed') ORDER BY o.id DESC LIMIT 100`).all();
  const items=db.prepare('SELECT * FROM order_items WHERE order_id=? ORDER BY id').all;
  res.json(orders.map(o=>({...o,items:items(o.id)})));
});
app.post('/api/orders', (req,res) => {
  const tableId=req.body.table_id ? Number(req.body.table_id) : null;
  if (tableId && !db.prepare('SELECT id FROM tables_room WHERE id=? AND active=1').get(tableId)) return res.status(400).json({error:'Mesa não encontrada.'});
  const employeeId=req.body.employee_id?Number(req.body.employee_id):null;
  if(employeeId&&!db.prepare('SELECT id FROM employees WHERE id=? AND active=1').get(employeeId)) return res.status(400).json({error:'Funcionário não encontrado.'});
  const info=db.prepare('INSERT INTO orders(table_id,customer,employee_id) VALUES(?,?,?)').run(tableId,String(req.body.customer||''),employeeId); broadcast(); res.status(201).json({id:info.lastInsertRowid});
});
app.patch('/api/orders/:id', (req,res) => {
  const customer=String(req.body.customer||'').trim();
  const info=db.prepare("UPDATE orders SET customer=? WHERE id=? AND status='open'").run(customer,req.params.id);
  if(!info.changes) return res.status(404).json({error:'Comanda aberta não encontrada.'});
  broadcast(); res.json({ok:true});
});
app.post('/api/orders/:id/items', (req,res) => {
  const orderId=Number(req.params.id), productId=Number(req.body.product_id), quantity=Number(req.body.quantity||1);
  const product=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(productId);
  const order=db.prepare("SELECT * FROM orders WHERE id=? AND status='open'").get(orderId);
  if(!product || !order || !Number.isFinite(quantity) || quantity<=0) return res.status(400).json({error:'Pedido, produto ou quantidade inválidos.'});
  const addItem = db.transaction(() => {
    const recipe = db.prepare('SELECT r.ingredient_id,r.quantity,i.name,i.stock FROM recipes r JOIN ingredients i ON i.id=r.ingredient_id WHERE r.product_id=? AND i.active=1').all(product.id);
    for (const part of recipe) if (part.stock < part.quantity * quantity) throw new Error(`Estoque insuficiente: ${part.name}.`);
    const item = db.prepare('INSERT INTO order_items(order_id,product_id,name,quantity,unit_price,notes) VALUES(?,?,?,?,?,?)').run(orderId,product.id,product.name,quantity,product.price,String(req.body.notes||'').trim());
    for (const part of recipe) {
      const used = part.quantity * quantity;
      db.prepare('UPDATE ingredients SET stock=stock-? WHERE id=?').run(used,part.ingredient_id);
      db.prepare("INSERT INTO stock_movements(ingredient_id,type,quantity,description) VALUES(?,'out',?,?)").run(part.ingredient_id,used,`Consumo na comanda #${orderId} · ${product.name}`);
    }
    return item;
  });
  try { addItem(); } catch (e) { return res.status(400).json({error:e.message}); }
  broadcast(); res.status(201).json({ok:true});
});
app.patch('/api/items/:id/status', (req,res) => {
  const allowed=['new','preparing','ready','delivered']; if(!allowed.includes(req.body.status)) return res.status(400).json({error:'Status inválido.'});
  db.prepare('UPDATE order_items SET status=? WHERE id=?').run(req.body.status,req.params.id); broadcast(); res.json({ok:true});
});
app.post('/api/orders/:id/close', (req,res) => {
  const info=db.prepare("UPDATE orders SET status='closed' WHERE id=? AND status='open'").run(req.params.id); if(!info.changes) return res.status(404).json({error:'Comanda aberta não encontrada.'}); broadcast(); res.json({ok:true});
});

function activeCash() { return db.prepare("SELECT * FROM cash_sessions WHERE status='open' ORDER BY id DESC LIMIT 1").get(); }
app.get('/api/cash/current', (_req,res) => {
  const session=activeCash();
  if(!session) return res.json({session:null,expected:0,movements:[],payments:[]});
  const payments=db.prepare('SELECT method,SUM(amount) amount FROM payments WHERE session_id=? GROUP BY method').all(session.id);
  const movements=db.prepare('SELECT * FROM cash_movements WHERE session_id=? ORDER BY id DESC').all(session.id);
  const paid=db.prepare('SELECT COALESCE(SUM(amount),0) total FROM payments WHERE session_id=?').get(session.id).total;
  const inflow=db.prepare("SELECT COALESCE(SUM(amount),0) total FROM cash_movements WHERE session_id=? AND type='in'").get(session.id).total;
  const outflow=db.prepare("SELECT COALESCE(SUM(amount),0) total FROM cash_movements WHERE session_id=? AND type='out'").get(session.id).total;
  res.json({session,expected:Number(session.opening_amount)+Number(paid)+Number(inflow)-Number(outflow),payments,movements});
});
app.post('/api/cash/open', (req,res) => {
  if(activeCash()) return res.status(400).json({error:'Já existe um caixa aberto.'});
  const amount=Number(req.body.amount||0); if(!Number.isFinite(amount)||amount<0) return res.status(400).json({error:'Valor de abertura inválido.'});
  const info=db.prepare('INSERT INTO cash_sessions(opening_amount) VALUES(?)').run(amount); broadcast(); res.status(201).json({id:info.lastInsertRowid});
});
app.post('/api/cash/movement', (req,res) => {
  const session=activeCash(); if(!session) return res.status(400).json({error:'Abra o caixa antes de registrar movimentações.'});
  const amount=Number(req.body.amount), type=req.body.type;
  if(!['in','out'].includes(type)||!Number.isFinite(amount)||amount<=0) return res.status(400).json({error:'Tipo ou valor inválido.'});
  db.prepare('INSERT INTO cash_movements(session_id,type,amount,method,description) VALUES(?,?,?,?,?)').run(session.id,type,amount,String(req.body.method||'cash'),String(req.body.description||'')); broadcast(); res.status(201).json({ok:true});
});
app.post('/api/cash/close', (req,res) => {
  const session=activeCash(); if(!session) return res.status(400).json({error:'Não há caixa aberto.'});
  const openOrders=db.prepare("SELECT COUNT(*) n FROM orders WHERE status='open' AND id IN (SELECT order_id FROM payments WHERE session_id=?)").get(session.id).n;
  if(openOrders) return res.status(400).json({error:'Existem comandas com pagamento pendente neste caixa.'});
  const current=db.prepare('SELECT COALESCE(SUM(amount),0) total FROM payments WHERE session_id=? AND method=\'cash\'').get(session.id).total;
  const inflow=db.prepare("SELECT COALESCE(SUM(amount),0) total FROM cash_movements WHERE session_id=? AND type='in' AND method='cash'").get(session.id).total;
  const outflow=db.prepare("SELECT COALESCE(SUM(amount),0) total FROM cash_movements WHERE session_id=? AND type='out' AND method='cash'").get(session.id).total;
  const expected=Number(session.opening_amount)+Number(current)+Number(inflow)-Number(outflow);
  const counted=Number(req.body.amount); if(!Number.isFinite(counted)||counted<0) return res.status(400).json({error:'Informe o valor contado no fechamento.'});
  db.prepare("UPDATE cash_sessions SET status='closed',closed_at=CURRENT_TIMESTAMP,closing_amount=? WHERE id=?").run(counted,session.id); broadcast(); res.json({expected,counted,difference:counted-expected});
});
app.post('/api/orders/:id/payments', (req,res) => {
  const session=activeCash(); if(!session) return res.status(400).json({error:'Abra o caixa antes de receber pagamentos.'});
  const order=db.prepare("SELECT * FROM orders WHERE id=? AND status='open'").get(req.params.id); if(!order) return res.status(404).json({error:'Comanda aberta não encontrada.'});
  const method=String(req.body.method||''); const amount=Number(req.body.amount);
  if(!['cash','pix','debit','credit'].includes(method)||!Number.isFinite(amount)||amount<=0) return res.status(400).json({error:'Forma de pagamento ou valor inválido.'});
  const total=db.prepare('SELECT COALESCE(SUM(quantity*unit_price),0) total FROM order_items WHERE order_id=?').get(order.id).total;
  const paid=db.prepare('SELECT COALESCE(SUM(amount),0) total FROM payments WHERE order_id=?').get(order.id).total;
  const balance=Number(total)-Number(paid); if(amount>balance+0.001) return res.status(400).json({error:`O valor excede o saldo de ${balance.toFixed(2)}.`});
  db.prepare('INSERT INTO payments(order_id,session_id,method,amount) VALUES(?,?,?,?)').run(order.id,session.id,method,amount);
  const newPaid=paid+amount; if(newPaid>=total-0.001) db.prepare("UPDATE orders SET status='closed' WHERE id=?").run(order.id);
  broadcast(); res.status(201).json({paid:newPaid,balance:Math.max(0,total-newPaid),closed:newPaid>=total-0.001});
});
app.get('/api/orders/:id/balance', (req,res) => {
  const total=db.prepare('SELECT COALESCE(SUM(quantity*unit_price),0) total FROM order_items WHERE order_id=?').get(req.params.id).total;
  const paid=db.prepare('SELECT COALESCE(SUM(amount),0) total FROM payments WHERE order_id=?').get(req.params.id).total;
  res.json({total,paid,balance:Math.max(0,total-paid),payments:db.prepare('SELECT * FROM payments WHERE order_id=? ORDER BY id').all(req.params.id)});
});
app.get('/api/ingredients', (_req,res) => res.json(db.prepare('SELECT * FROM ingredients WHERE active=1 ORDER BY name').all()));
app.post('/api/ingredients', (req,res) => {
  const name=String(req.body.name||'').trim(),unit=String(req.body.unit||'un'); const stock=Number(req.body.stock||0),min=Number(req.body.min_stock||0);
  if(!name||!Number.isFinite(stock)||stock<0||!Number.isFinite(min)||min<0) return res.status(400).json({error:'Confira nome e quantidades do ingrediente.'});
  const info=db.prepare('INSERT INTO ingredients(name,unit,stock,min_stock) VALUES(?,?,?,?)').run(name,unit,stock,min);
  if(stock>0) db.prepare("INSERT INTO stock_movements(ingredient_id,type,quantity,description) VALUES(?,'in',?,'Estoque inicial')").run(info.lastInsertRowid,stock);
  broadcast(); res.status(201).json({id:info.lastInsertRowid});
});
app.post('/api/ingredients/:id/movement', (req,res) => {
  const ingredient=db.prepare('SELECT * FROM ingredients WHERE id=? AND active=1').get(req.params.id); if(!ingredient) return res.status(404).json({error:'Ingrediente não encontrado.'});
  const type=req.body.type,quantity=Number(req.body.quantity); if(!['in','out'].includes(type)||!Number.isFinite(quantity)||quantity<=0) return res.status(400).json({error:'Movimentação inválida.'});
  if(type==='out'&&quantity>ingredient.stock) return res.status(400).json({error:'Estoque insuficiente.'});
  db.prepare('UPDATE ingredients SET stock=stock+? WHERE id=?').run(type==='in'?quantity:-quantity,ingredient.id);
  db.prepare('INSERT INTO stock_movements(ingredient_id,type,quantity,description) VALUES(?,?,?,?)').run(ingredient.id,type,quantity,String(req.body.description||'')); broadcast(); res.json({ok:true});
});
app.get('/api/recipes', (_req,res) => res.json(db.prepare('SELECT r.*,p.name product_name,i.name ingredient_name,i.unit FROM recipes r JOIN products p ON p.id=r.product_id JOIN ingredients i ON i.id=r.ingredient_id ORDER BY p.name,i.name').all()));
app.post('/api/recipes', (req,res) => {
  const productId=Number(req.body.product_id),ingredientId=Number(req.body.ingredient_id),quantity=Number(req.body.quantity);
  if(!db.prepare('SELECT id FROM products WHERE id=? AND active=1').get(productId)||!db.prepare('SELECT id FROM ingredients WHERE id=? AND active=1').get(ingredientId)||!Number.isFinite(quantity)||quantity<=0) return res.status(400).json({error:'Produto, ingrediente ou quantidade inválidos.'});
  db.prepare('INSERT INTO recipes(product_id,ingredient_id,quantity) VALUES(?,?,?) ON CONFLICT(product_id,ingredient_id) DO UPDATE SET quantity=excluded.quantity').run(productId,ingredientId,quantity); broadcast(); res.status(201).json({ok:true});
});


// Despesas e painel do proprietário
app.get('/api/expenses', (_req,res) => res.json(db.prepare("SELECT * FROM expenses ORDER BY expense_date DESC,id DESC LIMIT 200").all()));
app.post('/api/expenses', (req,res) => {
  const description=String(req.body.description||'').trim();
  const category=String(req.body.category||'Geral').trim();
  const amount=Number(req.body.amount);
  const payment_method=String(req.body.payment_method||'cash');
  const expense_date=String(req.body.expense_date||new Date().toISOString().slice(0,10));
  if(!description||!Number.isFinite(amount)||amount<=0||!['cash','pix','debit','credit','other'].includes(payment_method)||!/^\d{4}-\d{2}-\d{2}$/.test(expense_date)) return res.status(400).json({error:'Informe descrição, valor, forma de pagamento e data válidos.'});
  const info=db.prepare('INSERT INTO expenses(description,category,amount,payment_method,expense_date) VALUES(?,?,?,?,?)').run(description,category||'Geral',amount,payment_method,expense_date);
  broadcast(); res.status(201).json({id:info.lastInsertRowid});
});
app.delete('/api/expenses/:id', (req,res) => { const info=db.prepare('DELETE FROM expenses WHERE id=?').run(req.params.id); if(!info.changes)return res.status(404).json({error:'Despesa não encontrada.'}); broadcast(); res.json({ok:true}); });
app.get('/api/owner-dashboard', (_req,res) => {
  const today=db.prepare("SELECT date('now','localtime') d").get().d;
  const month=today.slice(0,7);
  const revenueToday=Number(db.prepare("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE date(created_at,'localtime')=?").get(today).total);
  const expensesToday=Number(db.prepare('SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE expense_date=?').get(today).total);
  const revenueMonth=Number(db.prepare("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE strftime('%Y-%m',created_at,'localtime')=?").get(month).total);
  const expensesMonth=Number(db.prepare("SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE substr(expense_date,1,7)=?").get(month).total);
  const lowStock=db.prepare('SELECT id,name,stock,min_stock,unit FROM ingredients WHERE active=1 AND stock<=min_stock ORDER BY name').all();
  const topProducts=db.prepare("SELECT oi.name,SUM(oi.quantity) quantity,SUM(oi.quantity*oi.unit_price) revenue FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE date(o.created_at,'localtime')=? GROUP BY oi.name ORDER BY quantity DESC LIMIT 5").all(today);
  const paymentMix=db.prepare("SELECT method,SUM(amount) amount FROM payments WHERE date(created_at,'localtime')=? GROUP BY method ORDER BY amount DESC").all(today);
  const employeePerformance=db.prepare("SELECT e.name,e.role,COUNT(DISTINCT p.order_id) orders,SUM(p.amount) revenue FROM payments p JOIN orders o ON o.id=p.order_id JOIN employees e ON e.id=o.employee_id WHERE date(p.created_at,'localtime')=? GROUP BY e.id ORDER BY revenue DESC").all(today);
  const daily=db.prepare("WITH RECURSIVE days(d,n) AS (SELECT date('now','localtime','-6 days'),0 UNION ALL SELECT date(d,'+1 day'),n+1 FROM days WHERE n<6) SELECT days.d date,COALESCE(SUM(p.amount),0) revenue FROM days LEFT JOIN payments p ON date(p.created_at,'localtime')=days.d GROUP BY days.d ORDER BY days.d").all();
  const openOrders=db.prepare("SELECT COUNT(*) n FROM orders WHERE status='open'").get().n;
  const openCash=!!activeCash();
  res.json({today,month,revenueToday,expensesToday,resultToday:revenueToday-expensesToday,revenueMonth,expensesMonth,resultMonth:revenueMonth-expensesMonth,lowStock,topProducts,paymentMix,employeePerformance,daily,openOrders,openCash});
});

app.get('/api/summary', (_req,res) => {
  const open=db.prepare("SELECT COUNT(*) n FROM orders WHERE status='open'").get().n;
  const sales=db.prepare("SELECT COALESCE(SUM(oi.quantity*oi.unit_price),0) total FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status='closed' AND date(o.created_at)=date('now','localtime')").get().total;
  res.json({open,sales,cashOpen:!!activeCash()});
});

io.on('connection', socket => socket.emit('connected',{ok:true}));
setTimeout(()=>createBackup().catch(console.error), 15000);
setInterval(()=>createBackup().catch(console.error), 24*60*60*1000);
server.listen(PORT,'0.0.0.0',()=>{
  const nets=os.networkInterfaces(); const ips=[];
  for(const list of Object.values(nets)) for(const net of (list||[])) if(net.family==='IPv4'&&!net.internal) ips.push(net.address);
  console.log(`Comanda Fácil disponível em http://localhost:${PORT}`);
  ips.forEach(ip=>console.log(`Celulares na mesma rede: http://${ip}:${PORT}`));
});
